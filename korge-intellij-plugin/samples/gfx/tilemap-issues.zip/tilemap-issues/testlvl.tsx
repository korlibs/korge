<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.2" name="testlvl" tilewidth="16" tileheight="16" tilecount="3" columns="3">
 <image source="testlvl.png" width="48" height="16"/>
</tileset>
