package org.jcodec.containers.dpx;

public class FilmHeader {
    public String idCode;
    public String type;
    public String offset;
    public String prefix;
    public String count;
    public String format;
//        public byte[] reserved;
}
