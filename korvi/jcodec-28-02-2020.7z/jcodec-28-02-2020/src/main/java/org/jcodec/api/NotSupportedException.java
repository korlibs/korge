package org.jcodec.api;

public class NotSupportedException extends RuntimeException {

	public NotSupportedException(String msg) {
		super(msg);
	}

}
