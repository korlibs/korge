package org.jcodec.scale;

public enum InterpFilter {
    LANCZOS, BICUBIC;
}
