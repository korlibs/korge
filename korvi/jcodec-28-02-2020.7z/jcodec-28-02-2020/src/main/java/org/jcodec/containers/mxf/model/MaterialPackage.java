package org.jcodec.containers.mxf.model;

/**
 * This class is part of JCodec ( www.jcodec.org ) This software is distributed
 * under FreeBSD License
 * 
 * @author The JCodec project
 * 
 */
public class MaterialPackage extends GenericPackage {

    public MaterialPackage(UL ul) {
        super(ul);
    }
   
}