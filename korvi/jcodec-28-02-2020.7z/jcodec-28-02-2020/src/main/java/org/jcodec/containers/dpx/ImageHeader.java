package org.jcodec.containers.dpx;

public class ImageHeader {
    public short orientation;
    public short numberOfImageElements;
    public int linesPerImageElement;
    public int pixelsPerLine;
    public ImageElement imageElement1;
}
