package org.jcodec.containers.dpx;

public class ImageElement {
    public int dataSign;
}
