package org.jcodec;

import java.io.File;

public class TestData {

    public static final File AVID_EMPTY_INDEX_MXF = new File("src/test/resources/mxf/LTD16562_SYN16562-PUNCH.mxf");
    public static final File TIMECODE_MXF = new File("src/test/resources/mxf/timecode.mxf");
    public static final File TIMECODE_OFFSET_MXF = new File("src/test/resources/mxf/timecode_withoffset.mxf");
    public static final File TWO_TIMECODES_MXF = new File("src/test/resources/mxf/two_timecodes.mxf");
    public static final File TIMECODE_MXF_3 = new File("src/test/resources/mxf/timecode_onemore.mxf");

}
