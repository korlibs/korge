package org.jcodec.common.tools;
import org.junit.Test;

import java.lang.System;

public class MathUtilTest {

    @Test
    public void test() {
        System.out.println(MathUtil.nextPowerOfTwo(1024));
    }

}
